Just call one of the interactive functions in this file to complete
the corresponding thing using `ivy'.

Currently available:
- Symbol completion for Elisp, Common Lisp, Python, Clojure, C, C++.
- Describe functions for Elisp: function, variable, library, command,
  bindings, theme.
- Navigation functions: imenu, ace-line, semantic, outline.
- Git utilities: git-files, git-grep, git-log, git-stash, git-checkout.
- Grep utilities: grep, ag, pt, recoll, ack, rg.
- System utilities: process list, rhythmbox, linux-app.
- Many more.
