lsp-ui contains a series of useful UI integrations for lsp-mode, like
flycheck support and code lenses.
