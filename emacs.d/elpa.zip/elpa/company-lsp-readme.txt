`company-lsp' is a `company' completion backend for `lsp-mode'.
To use it, add `company-lsp' to `company-backends':

    (require 'company-lsp)
    (push 'company-lsp company-backends)
