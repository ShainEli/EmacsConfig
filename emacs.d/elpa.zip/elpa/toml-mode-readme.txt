This is a major mode for editing files in TOML data format
